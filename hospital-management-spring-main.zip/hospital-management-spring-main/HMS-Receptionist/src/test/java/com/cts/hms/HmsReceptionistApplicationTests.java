package com.cts.hms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HmsReceptionistApplicationTests {

	@Test
	void contextLoads() {
	}

}
